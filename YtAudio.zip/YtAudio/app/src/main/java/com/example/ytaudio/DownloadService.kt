package com.example.ytaudio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Executors.newSingleThreadExecutor().asCoroutineDispatcher())
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private var pending = 0
    private var ready = false
    private var counter = 100

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        nm.createNotificationChannel(NotificationChannel("dl", "التحميل", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("done", "النتيجة", NotificationManager.IMPORTANCE_DEFAULT))
        startForeground(1, progressNotif("جاري التحميل...", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        val url = intent?.getStringExtra("url")
        if (url == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        pending++
        scope.launch {
            val msg = try {
                "تم الحفظ ✅ " + convert(url)
            } catch (e: Exception) {
                val m = e.message ?: ""
                if ("Errno 7" in m || "Errno 101" in m || "unreachable" in m || "hostname" in m)
                    "تعذّر الاتصال بيوتيوب ❌ تحقق من الإنترنت، وأوقف الـ VPN أو الـ DNS الخاص ثم أعد المحاولة"
                else
                    "فشل التحميل ❌ " + (m.lines().lastOrNull { "ERROR" in it } ?: m).take(150)
            }
            withContext(Dispatchers.Main) {
                val n = NotificationCompat.Builder(this@DownloadService, "done")
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("تحميل صوت")
                    .setContentText(msg)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
                    .setAutoCancel(true)
                    .build()
                nm.notify(counter++, n)
                pending--
                if (pending <= 0) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun progressNotif(text: String, pct: Int): Notification =
        NotificationCompat.Builder(this, "dl")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("تحميل صوت")
            .setContentText(text)
            .setOngoing(true)
            .setProgress(100, pct.coerceAtLeast(0), pct < 0)
            .build()

    private fun update() {
        runCatching { YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.NIGHTLY) }
        getSharedPreferences("p", 0).edit().putLong("u", System.currentTimeMillis()).apply()
    }

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun waitForNetwork() {
        var t = 0
        while (!online() && t < 60) { Thread.sleep(1000); t++ }
        if (!online()) error("ERROR: Network is unreachable")
    }

    private fun convert(url: String): String {
        waitForNetwork()
        if (!ready) {
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)
            ready = true
        }
        val last = getSharedPreferences("p", 0).getLong("u", 0)
        if (System.currentTimeMillis() - last > 12 * 3600_000L) update()
        val dir = File(cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
        val file = try {
            download(url, dir)
        } catch (e: Exception) {
            waitForNetwork()
            update()
            download(url, dir)
        }
        saveToMusic(file)
        val name = file.nameWithoutExtension
        file.delete()
        return name
    }

    private fun download(url: String, dir: File): File {
        val mp3 = getSharedPreferences("p", 0).getBoolean("mp3", false)
        val req = YoutubeDLRequest(url).apply {
            addOption("-f", "bestaudio[ext=m4a]/bestaudio")
            addOption("-x")
            if (mp3) {
                addOption("--audio-format", "mp3")
                addOption("--audio-quality", "5")
            }
            addOption("--no-playlist")
            addOption("-N", "8")
            addOption("--http-chunk-size", "10M")
            addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
        }
        var lastPct = -1
        YoutubeDL.getInstance().execute(req) { p, _, _ ->
            val i = p.toInt()
            if (i >= 0 && i != lastPct) {
                lastPct = i
                nm.notify(1, progressNotif("$i%", i))
            }
        }
        return dir.listFiles()?.firstOrNull { it.extension in setOf("m4a", "mp3", "opus", "ogg", "aac", "webm") } ?: error("لم يتم إنشاء الملف")
    }

    private fun saveToMusic(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, file.name)
            put(
                MediaStore.Audio.Media.MIME_TYPE,
                when (file.extension) {
                    "mp3" -> "audio/mpeg"
                    "m4a", "aac" -> "audio/mp4"
                    else -> "audio/ogg"
                }
            )
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/YtAudio")
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
    }

    companion object {
        fun start(ctx: Context, url: String) {
            ctx.startForegroundService(Intent(ctx, DownloadService::class.java).putExtra("url", url))
        }
    }
}
