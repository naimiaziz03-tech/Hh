package com.example.ytaudio

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val input = EditText(this).apply { hint = "الصق رابط الفيديو هنا" }
        val button = Button(this).apply { text = "تحميل ⬇️" }
        val tip = TextView(this).apply {
            text = "أو من يوتيوب: مشاركة ← تحميل صوت MP3\nيعمل التحميل في الخلفية ويُحفظ في Music/YtAudio"
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 0)
        }
        root.addView(input); root.addView(button); root.addView(tip)
        setContentView(root)

        button.setOnClickListener {
            val url = Regex("https?://\\S+").find(input.text.toString())?.value
            if (url == null) {
                Toast.makeText(this, "الصق رابطاً صحيحاً", Toast.LENGTH_SHORT).show()
            } else {
                DownloadService.start(this, url)
                input.setText("")
                Toast.makeText(this, "بدأ التحميل في الخلفية ⬇️", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
