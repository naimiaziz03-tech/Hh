package com.example.ytaudio

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var button: Button
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        input = EditText(this).apply { hint = "الصق رابط الفيديو هنا" }
        button = Button(this).apply { text = "تحويل إلى صوت MP3" }
        status = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }
        root.addView(input); root.addView(button); root.addView(status)
        setContentView(root)

        button.setOnClickListener { convert(input.text.toString()) }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val url = Regex("https?://\\S+").find(text)?.value ?: return
            input.setText(url)
            convert(url)
        }
    }

    private fun convert(url: String) {
        if (!url.startsWith("http")) { status.text = "رابط غير صالح"; return }
        button.isEnabled = false
        status.text = "جاري التحضير..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (!ready) {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                    ready = true
                }
                val dir = File(cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
                val req = YoutubeDLRequest(url).apply {
                    addOption("-x")
                    addOption("--audio-format", "mp3")
                    addOption("--no-playlist")
                    addOption("-o", "${dir.absolutePath}/%(title)s.%(ext)s")
                }
                YoutubeDL.getInstance().execute(req) { p, _, _ ->
                    runOnUiThread { status.text = "جاري التحويل... ${p.toInt()}%" }
                }
                val out = dir.listFiles()?.firstOrNull { it.extension == "mp3" }
                    ?: error("لم يتم إنشاء الملف")
                saveToMusic(out)
                withContext(Dispatchers.Main) { status.text = "تم الحفظ في Music/YtAudio ✅\n${out.name}" }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { status.text = "فشل التحويل: ${e.message}" }
            } finally {
                withContext(Dispatchers.Main) { button.isEnabled = true }
            }
        }
    }

    private fun saveToMusic(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/YtAudio")
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
    }
}
