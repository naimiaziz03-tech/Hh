package com.example.ytaudio

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val url = Regex("https?://\\S+").find(text)?.value
        if (url != null) {
            DownloadService.start(this, url)
            Toast.makeText(this, "بدأ التحميل في الخلفية ⬇️", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "لم أجد رابطاً صالحاً", Toast.LENGTH_SHORT).show()
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
